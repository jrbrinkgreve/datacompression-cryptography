entropyFunc = @(p) -sum(p(p > 0) .* log2(p(p > 0)));
nCycles = 1000;

%init
ciphertext_distribution_storage = 0;
joint_distribution_storage = 0;
MI_storage = 0;
H_ciphertext_storage = 0;
H_joint_storage = 0;

%preprocess
plaintext = fileread('sample_text.txt'); 
plaintext = lower(plaintext); %lowercase
plaintext = regexprep(plaintext, '[^a-z .,012]', ''); %keep only a-z and spaces, dots, commas, 012

close all




%compute frequency distribution of plaintext characters
unique_chars_plaintext = unique(plaintext);
plaintext_remapped = uint8(remap_characters(plaintext));
n = length(plaintext);

index = 1;
for i = unique_chars_plaintext
    p_hist(index) = count(plaintext, i);
    index = index + 1;
end
p_hist = p_hist / n;


%entropy:
H_plaintext = entropyFunc(p_hist);

%loop for averaging
for i = 1:nCycles

%generate key
key = randi([0,31], size(plaintext), 'uint8');   %randi([0,31]

%encrypt using one-time pad
ciphertext_remapped = bitxor(plaintext_remapped, key);
ciphertext = inverse_remap_characters(ciphertext_remapped);


%distribution of ciphertext characters
unique_chars_ciphertext = unique(ciphertext);
index = 1;
for i = unique_chars_ciphertext
    c_hist(index) = count(ciphertext, i);
    index = index + 1;
end
c_hist = c_hist / n;


%entropy:
H_ciphertext = entropyFunc(c_hist);


%decoding using ciphertext and key
decoded_string_unicode = bitxor(ciphertext_remapped, key);
decoded_string = inverse_remap_characters(decoded_string_unicode);

%for plotting the uniform dist.
ciphertext_distribution_storage = ciphertext_distribution_storage + c_hist;


%joint histogram and entropy
jointHist = histcounts2(plaintext_remapped , ciphertext_remapped, length(unique_chars_plaintext), 'Normalization', 'probability');
H_joint = entropyFunc(jointHist(:));


% Mutual Information formula: I(X;Y) = H(X) + H(Y) - H(X,Y)
MI = H_ciphertext + H_plaintext - H_joint;




%averaging
MI_storage = MI_storage + MI;
H_ciphertext_storage = H_ciphertext_storage + H_ciphertext;
H_joint_storage = H_joint_storage + H_joint;
joint_distribution_storage = joint_distribution_storage + jointHist;

end

%averaging
ciphertext_distribution_storage = ciphertext_distribution_storage / nCycles;
MI_storage = MI_storage / nCycles;
H_ciphertext_storage = H_ciphertext_storage / nCycles;
H_joint_storage = H_joint_storage / nCycles;
joint_distribution_storage = joint_distribution_storage / nCycles;







%plotting

figure
bar(p_hist)
title('Single iteration plaintext histogram')
ylabel('Probability per character')
set(gca, 'xtick', 1:32, 'xticklabel', {'space', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', ...
                                       'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', ',', '.', '0', '1', '2'});
ax = gca; 
ax.FontSize = 28; 

figure
bar(c_hist)
title('Single iteration ciphertext histogram')
ylabel('Probability per character')
set(gca, 'xtick', 1:32, 'xticklabel', {'space', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', ...
                                       'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', ',', '.', '0', '1', '2'});
ax = gca; 
ax.FontSize = 28; 


figure
bar(ciphertext_distribution_storage)
title('Averaged ciphertext histogram over nCycles')
ylabel('Probability per character')
set(gca, 'xtick', 1:32, 'xticklabel', {'space', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', ...
                                       'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', ',', '.', '0', '1', '2'});
ax = gca; 
ax.FontSize = 28; 


figure
bar3(joint_distribution_storage)
title('Averaged joint histogram over nCycles')
xlabel('Ciphertext')
ylabel('Plaintext')
zlabel('Probability')
set(gca, 'xtick', 1:32, 'xticklabel', {'space', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', ...
                                       'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', ',', '.', '0', '1', '2'});
set(gca, 'ytick', 1:32, 'yticklabel', {'space', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', ...
                                       'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', ',', '.', '0', '1', '2'});

ax = gca; 
ax.FontSize = 20; 




%displaying values
disp(['HP: ', num2str(H_plaintext)]);
disp(['HC: ', num2str(H_ciphertext_storage)]);
disp(['H_joint: ', num2str(H_joint_storage)]);
disp(['Mutual Information: ', num2str(MI_storage)]);



