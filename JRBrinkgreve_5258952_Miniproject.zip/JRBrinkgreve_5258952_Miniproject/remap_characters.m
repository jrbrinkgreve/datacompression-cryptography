function id = remap_characters(input)

id = uint8(input) - 96;  % Convert all characters at once
id(input == ' ') = 0;      % Assign 0 for spaces
id(input == ',') = 27;
id(input == '.') = 28;
id(input == '0') = 29;
id(input == '1') = 30;
id(input == '2') = 31;

end
