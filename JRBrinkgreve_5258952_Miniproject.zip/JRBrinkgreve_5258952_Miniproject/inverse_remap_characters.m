function output = inverse_remap_characters(input)


output = char(input + 96);  
output(input == 0) = ' ';      
output(input == 27) = ',';     
output(input == 28) = '.';    
output(input == 29) = '0';     
output(input == 30) = '1';     
output(input == 31) = '2';     

end
